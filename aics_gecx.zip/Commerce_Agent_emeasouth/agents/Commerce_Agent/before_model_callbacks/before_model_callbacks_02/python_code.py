def before_model_callback(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
  for part in callback_context.get_last_user_input():
    # Or other events or texts
    if part.text == "<event>ORDER_SUPPORT</event>":
      return LlmResponse.from_parts(parts=[Part.from_text('Apparently you need some support for you order, let me have a look at it.'), Part.from_agent_transfer(agent='Order Support')])
  return None