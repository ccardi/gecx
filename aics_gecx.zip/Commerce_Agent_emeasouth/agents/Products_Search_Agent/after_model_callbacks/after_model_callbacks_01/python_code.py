import json
from typing import Optional

def after_model_callback(callback_context: CallbackContext, llm_response: LlmResponse) -> Optional[LlmResponse]:
    try:
        last_event = callback_context.events[-1]
        
        # 1. Find all parts that match your criteria
        matching_parts = [
            part for part in last_event.content.parts 
            if part.has_function_response("searchMultipleProducts")
        ]
        
        # 2. If there are any matches, look ONLY at the last one
        if matching_parts:
            last_part = matching_parts[-1]
            
            # 3. Process that single last part
            func_resp = getattr(last_part, 'function_response', None)
            if func_resp:
                result = getattr(func_resp, "response", None)
                if result:
                    results = result.get("result", {})
                    
                    if results:
                        llm_response.content.parts.append(Part.from_json(data=json.dumps({
                           "payload":{
                              "queries": results.get("queries"),
                              "queryResults": results.get("queryResults")
                           }, 
                           "type": "custom_template", 
                           "name": "products-carousels"
                        })))
                        
    except (IndexError, AttributeError, KeyError) as e:
        print(f"Callback skipped or failed to update state: {e}")
    
    return llm_response