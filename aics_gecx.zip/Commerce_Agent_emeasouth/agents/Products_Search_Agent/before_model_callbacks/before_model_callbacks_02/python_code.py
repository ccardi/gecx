def before_model_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest
) -> Optional[LlmResponse]:
  if  llm_request.contents[-1].parts[-2].has_function_response('searchMultipleProducts'):
    response = LlmResponse.from_parts([Part.from_json(data=json.dumps({"message":"searchMultipleProducts"}))])
    response.partial = True
    return response
  return None