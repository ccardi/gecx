def before_model_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest
) -> Optional[LlmResponse]:
  print(llm_request.contents[-1].parts[-1])
  if  llm_request.contents[-1].parts[-1].has_function_response('travel-datastore'):
    response = LlmResponse.from_parts([Part.from_json(data=json.dumps({"message":"travel-datastore"}))])
    response.partial = True
    return response
  return None