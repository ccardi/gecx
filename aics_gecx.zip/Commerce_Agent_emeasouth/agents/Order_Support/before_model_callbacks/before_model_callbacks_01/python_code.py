def before_model_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest
) -> Optional[LlmResponse]:
  
  for idx, event in enumerate(callback_context.events):
    #print("Callback Context event: ", idx, {"event_content": event})
    if event.content:
     
      for part in  event.content.parts:
        if part:
          if part.has_function_call("transfer_to_agent"): 
            if part.function_call.args.get("agent_name")=="Order Support":
              if idx==len(callback_context.events)-2:
                
                response = LlmResponse.from_parts([Part.from_json(data=json.dumps({"thinking": "Let me transfer this request to Order Support Agent"}))])
                response.partial = True
                return response
  return None