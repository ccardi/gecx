import json
from typing import Optional

def after_model_callback(callback_context: CallbackContext, llm_response: LlmResponse) -> Optional[LlmResponse]:
    try:
        last_event = callback_context.events[-1]
        last_part = last_event.content.parts[-1]
        #print(last_part.has_function_response("searchMultipleProducts"))
        #print(last_part)
        if last_part.has_function_response("searchMultipleProducts"):
          # Check if the part actually contains a function_response
          func_resp = getattr(last_part, 'function_response', None)
          if func_resp is None:
              return llm_response
          result = getattr(func_resp,"response", None)
          #print(result)
          if result:
              results=result.get("result")
              llm_response.content.parts.append(Part.from_json(data=json.dumps({
                 "payload":{
                    "queries":results.get("queries"),
                    "queryResults": results.get("queryResults")
                 }, 
                 "type":"custom_template", "name": "products-carousels"
              } )))
              return llm_response
                        
    except (IndexError, AttributeError, KeyError) as e:
        print(f"Callback skipped or failed to update state: {e}")
    
    return llm_response