def call_vertex_ai()->dict:
  results = tools.vertex_ai_gemini_vertex_ai_generateContent({
  "projectId": "pod-fr-retail",
  "location": "global",
  "modelId": "gemini-2.5-flash-lite",
  "contents": [
    {
      "role": "user",
      "parts": [
        {
          "text": "Classify the following business description: 'A local shop that sells handmade ceramic plates and mugs directly to walk-in customers.'"
        }
      ]
    }
  ],
  "generationConfig": {
    "responseMimeType": "application/json",
    "responseSchema": {
      "type": "object",
      "properties": {
        "category": {
          "type": "string",
          "enum": [
            "retail",
            "not retail"
          ],
          "description": "The classification of the business based on the description provided."
        },
        "confidence_score": {
          "type": "number",
          "description": "A value between 0 and 1 representing the certainty of the classification."
        },
        "reasoning": {
          "type": "string",
          "description": "A brief explanation of why this category was chosen."
        }
      },
      "required": [
        "category",
        "confidence_score",
        "reasoning"
      ]
    },
    "maxOutputTokens": 1000,
    "temperature": 0,
    "topP": 0.95
  }
})
  data = results.json()
  candidates = data.get("candidates", [])
  if not candidates:
      return {"error": "No candidates returned."}
      
  raw_text = candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "{}")
  
  # 3. Since we requested JSON output, parse the string back into a Python dictionary
  try:
      #structured_output = json.loads(raw_text)
      return raw_text
  except json.JSONDecodeError:
      return {"error": "Failed to parse JSON", "raw_text": raw_text}