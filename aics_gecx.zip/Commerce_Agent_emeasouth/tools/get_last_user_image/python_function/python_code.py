from typing import Optional

def get_last_user_image() -> Optional[str]:
  """
  Retrieves the most recent message sent by the user from the conversation history.
  Returns:
    The text of the last user message, or None if no user messages are found.
  """
  user_messages = []
  # Verify the main object exists first
  if context.user_content and context.user_content.role == "user":
      for part in context.user_content.parts:
          # Safely drill down: part -> inline_data -> inline_data
          inline_obj = getattr(part, 'inline_data', None)
          
          if inline_obj:
              data = getattr(inline_obj, 'data', None)
              if data:
                  user_messages.append(data)


  if user_messages:
    # Returning the first text part of the most recent message
    return {"user_image": user_messages[0]}

  return None