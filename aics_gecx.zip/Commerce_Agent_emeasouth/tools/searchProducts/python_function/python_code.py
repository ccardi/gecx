def searchProducts(query: str) -> dict:
  config = context.state.get("config_vaisc")
  # Create a brand new local dictionary
  local_config = {**config, "query": query}
  results = tools.search_commerce_Search(local_config)
  data = results.json()
  products = []
  for e in data.get("results", [])[:50]:
      product_data = e.get("product", {})
      images = product_data.get("images", [])
      
      # Extract price safely
      price_info = product_data.get("priceInfo", {})
      price_val = price_info.get("price", "N/A")

      products.append({
          "productId": e.get("id"),
          "title": product_data.get("title", "")[:40],
          "uri": product_data.get("uri"),
          # Only take index 0 if the list isn't empty
          "imageUris": [images[0]["uri"]] if images else [],
          "subtitle": "",
          "price": f"{price_val}GDB"
      })

  # THE CALLBACK PAYLOAD
  # Save to state so the callback can find it
  #context.state["last_search_results"] = products
  
  # Return a simple flag for the LLM
  return {"query": query, "status": "success", "count": data["totalSize"], "products":products}