import random

def get_order_details(orderId: str) -> dict:
  config = context.state["config_spanner"]
  # 1. Fetch existing sessions
  sessions_response = tools.spanner_retail_sessionsList(config)
  # Extract the sessions list. 
  # (Adjust this if tools.spanner_retail_sessionsList returns a direct list instead of a dict)
  sessions_list = sessions_response.json().get("sessions", [])
  if sessions_list:
      # Existing sessions? YES -> Use one randomly
      session = random.choice(sessions_list)["name"]
  else:
      # Existing sessions? NO -> Create one
      response = tools.spanner_retail_sessionsCreate(config)
      print(response)
      session = response.json()["name"]
  
  results = tools.spanner_retail_executeSql(
    {
    "session": session,
    "sql":"SELECT p.ProductID,Name, Category, PriceUSD FROM OrderItems o JOIN Products p on o.ProductID=p.ProductID where OrderID="+ orderId
    })

  return results.json()