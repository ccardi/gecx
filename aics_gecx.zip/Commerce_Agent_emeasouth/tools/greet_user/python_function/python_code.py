def greet_user(name: str) -> str:
  """Provides a simple greeting. If a name is provided, it will be used.

  Args:
    name (str, optional): The name of the person to greet.

  Returns:
    str: A friendly greeting message.
  """
  if name:
    greeting = f"Hello, {name}!"
  else:
    greeting = "Hello there! I can help you for shopping, find a store, your past orders for instance"
  return greeting