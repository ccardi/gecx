def get_cloud_run(entrypoint: str, user:str, role:str) -> dict:
  """Makes some sequential API calls."""
  response = tools.Cloud_Run_Example_helloHttp({"entrypoint": entrypoint, "user":user, "role":role})

  return response.json()