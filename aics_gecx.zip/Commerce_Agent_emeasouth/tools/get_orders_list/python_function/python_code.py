import random

def get_orders_list() -> dict:
    config = context.state["config_spanner"]
    # 1. Check if session variable already exists in state
    session = context.state.get('spanner_session')
    print(session)
    if session is None:
        # 2. Variable doesn't exist -> Call session_list
        sessions_response = tools.spanner_retail_sessionsList(config)
        sessions_list = sessions_response.json().get("sessions", [])
        
        if sessions_list:
            # Existing sessions found -> Pick one randomly
            session = random.choice(sessions_list)["name"]
            context.state["spanner_session"] = session
        else:
            # List is empty -> Create a new one
            response = tools.spanner_retail_sessionsCreate(config)
            session = response.json()["name"]
            context.state["spanner_session"] = session       
    
    # 3. Execute SQL using the confirmed session
    user_id = str(context.state["UserId"]) 
    results = tools.spanner_retail_executeSql({
        "session": session,
        "sql": f"SELECT OrderId, OrderDate, TotalAmountUSD, OrderStatus FROM Orders WHERE UserId={user_id}"
    })

    return results.json()