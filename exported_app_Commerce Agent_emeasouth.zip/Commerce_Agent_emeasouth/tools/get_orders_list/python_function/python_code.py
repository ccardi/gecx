import random

def get_orders_list() -> dict:
    config = context.state["config_spanner"]
    
    # 1. Fetch existing sessions
    sessions_response = tools.spanner_retail_sessionsList(config)
    
    # Extract the sessions list. 
    # (Adjust this if tools.spanner_retail_sessionsList returns a direct list instead of a dict)
    sessions_list = sessions_response.json().get("sessions", [])
    
    if sessions_list:
        # Existing sessions? YES -> Use one randomly
        session = random.choice(sessions_list)["name"]
    else:
        # Existing sessions? NO -> Create one
        response = tools.spanner_retail_sessionsCreate(config)
        session = response.json()["name"]
        
    # Optional: Save it back to state so other parts of your app can reuse the active session
    context.state["spanner_session"] = session
    
    # 3. Use session to get orders
    # Wrapping UserId in str() just in case it's stored as an int in the state
    UserId = str(context.state["UserId"]) 
    results = tools.spanner_retail_executeSql({
        "session": session,
        "sql": "select OrderId,OrderDate,TotalAmountUSD, OrderStatus from Orders where UserId=" + UserId
    })

    return results.json()